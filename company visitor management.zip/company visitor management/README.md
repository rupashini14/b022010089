#  assignment benr 2423

COMPANY VISITOR MANAGEMENT SYSTEM
 
 Objectives:
To create a backend solution for a VMS capable of tracking facility user access information. By using this visitor management system, our aim is to keep the track of who is (or was) in our company.

 Requirement :
- Ease of use
   _log in process with id name and password created_
- Stuctural record
    _Easy to get the specific information we want_
- Cuztomizable field
    _Can add new visitor by registration name and password_
- Security Concerned
    _Personal informations is only viewable by users and database manager_

    Team Member:

 Programmer – Raja Khairani 
 
 Quality Assurance – Putri Nur Nabila
 
 Production Engineer – Rupashini

 ![Use-Case Diagram] (https://drive.google.com/file/d/1B2kmt-uGXCR2j1I7eVSah3dkmbCQnkkK/view?usp=sharing)


  ![Crow's Foot Diagram] (https://drive.google.com/file/d/1ug8GxiFokctvV4wf_VH7j1qEwY-BMI53/view?usp=sharing)
  